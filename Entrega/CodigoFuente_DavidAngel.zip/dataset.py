import os
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset


# ──────────────────────────────────────────────────────────────────────────────
# SPECTROGRAM TENSOR DATASET
# ──────────────────────────────────────────────────────────────────────────────
# Clase hija de Dataset (pytorch)
# Normaliza los valores para evitar que el carrier (el parámetro con valores más grandes) domine la pérdida
class SpectrogramTensorDataset(Dataset):
    def __init__(self, tensors_dir, param_cols=('carrier', 'ratio', 'index', 'amp_attack', 'amp_sustain', 'amp_decay', 'mod_attack', 'mod_decay')):
        self.tensors_dir = tensors_dir
        self.param_cols = list(param_cols)

        # Localizar CSV en la propia carpeta de tensores
        labels_csv = os.path.join(tensors_dir, "labels.csv")
        if not os.path.exists(labels_csv):
            raise FileNotFoundError(f"labels.csv no encontrado en {labels_csv}")
        df = pd.read_csv(labels_csv)

        # Calcular valores para normalización
        vals = df[self.param_cols].astype(np.float32).values
        self.param_means = vals.mean(axis=0).astype(np.float32)  # Se hace la media de cada parametro
        stds = vals.std(axis=0).astype(np.float32)               # Se calcula la desviación estándar de cada parámetro
        stds[stds == 0] = 1.0   # evitar división por 0
        self.param_stds = stds

        # Normalizar todos los parámetros de golpe (vectorizado) y construir el diccionario
        keys = df["filename"].astype(str).str.strip().apply(
            lambda f: os.path.splitext(f)[0].lower()
        )
        vals_norm = (vals - self.param_means) / self.param_stds  # Z score 
        self.labels = dict(zip(keys, vals_norm))

        # listar .pt en tensors_dir
        files = [f for f in os.listdir(tensors_dir) if f.lower().endswith('.pt')]
        files.sort()
        if len(files) == 0:
            raise RuntimeError(f"No se encontraron archivos .pt en {tensors_dir}")
        self.files = files

    def __len__(self):
        return len(self.files)

    # Devuelve el tensor espectrograma y otro con sus parametros normalizados
    def __getitem__(self, idx):
        # En base al indice que recibe, busca su nombre
        fname = self.files[idx]
        key = os.path.splitext(fname)[0].lower()

        # Construye su ruta al .pt original y lo carga
        spec_path = os.path.join(self.tensors_dir, fname)
        spectrogram = torch.load(spec_path, map_location="cpu").float()  # Es mejor tenerlos en CPU en este momento, luego pasaremos a GPU

        # Asegurar forma (C,H,W) donde C es 1, importante pues waveform_to_spectrogram_tensor() devuelve un tensor (freq_bins, time_frames), sin canal!!
        if spectrogram.dim() == 2:
            spectrogram = spectrogram.unsqueeze(0)

        # Obtener parámetros normalizados
        if key not in self.labels:
            raise KeyError(f"Etiqueta no encontrada para {key}")
        params = torch.tensor(self.labels[key], dtype=torch.float32)

        return spectrogram, params

    # Desnormaliza un vector de parámetros
    def denormalize(self, params_norm):
        if isinstance(params_norm, torch.Tensor):   # Si es tensor pytorch
            device = params_norm.device
            dtype = params_norm.dtype
            mean_t = torch.from_numpy(self.param_means).to(device=device, dtype=dtype)
            std_t = torch.from_numpy(self.param_stds).to(device=device, dtype=dtype)
            return params_norm * std_t + mean_t
        else:                                        # Si es array numpy
            arr = np.asarray(params_norm, dtype=np.float32)
            return arr * self.param_stds + self.param_means

    # Obtener las medias y desviaciones estándar
    def get_stats(self):
        return {'means': self.param_means.copy(), 'stds': self.param_stds.copy()}
